To run the test file open it with you favourite IDE (I use IntelliJ) run the class.

In order to see the printouts I copied some section of the tests and pasted it in the file src/owntest.java.
 Compile the file and run it to see the printouts